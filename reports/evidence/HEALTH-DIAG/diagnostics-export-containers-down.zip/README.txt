Blackbox diagnostics export (local, explicit).
Range: 2026-11-02T00:31:34.108Z .. 2026-11-02T02:31:34.109Z
Categories: versions, health, errors, logs
Truncated: false
Unavailable: health: runtime probes unavailable (API/database down)
Identifiers are pseudonymized consistently within this bundle; no credentials, business content, evidence or personal paths are included.
